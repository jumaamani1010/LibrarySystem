
package librarysystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Database {
    private static final String DB_URL = "jdbc:ucanaccess:// C:\\Users\\USER\\Dropbox\\PC\\Desktop\\SYSTEM COURSEWORK";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    public static List<VULibrarySystem> getAllBooks() throws SQLException {
        List<VULibrarySystem> books = new ArrayList<>();
        String query = "SELECT * FROM newBooksForm";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                books.add(new VULibrarySystem(
                        rs.getInt("BookID"),
                        rs.getString("Title"),
                        rs.getString("Author"),
                        rs.getInt("Year")
                ));
            }
        }
        return books;
    }

    public static void addBook(VULibraySystem books) throws SQLException {
        String query = "INSERT INTO Books (Title, Author, Year) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, books.getTitle());
            pstmt.setString(2, books.getAuthor());
            pstmt.setInt(3, books.getYear());
            pstmt.executeUpdate();
        }
    }

    public static void deleteBook(int bookID) throws SQLException {
        String query = "DELETE FROM Books WHERE BookID = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, bookID);
            pstmt.executeUpdate();
        }
    }

    static void addBook() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
