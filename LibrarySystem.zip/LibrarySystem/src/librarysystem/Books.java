
package librarysystem;



public class Books {

private int bookID;
    private String title;
    private String author;
    private int year;

    public Books(int bookID, String title, String author, int year) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.year = year;
    }




    
}
